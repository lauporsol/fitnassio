
package Endomondo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "moment",
    "request-promise-native",
    "uuid"
})
public class Dependencies {

    @JsonProperty("moment")
    private String moment;
    @JsonProperty("request-promise-native")
    private String requestPromiseNative;
    @JsonProperty("uuid")
    private String uuid;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("moment")
    public String getMoment() {
        return moment;
    }

    @JsonProperty("moment")
    public void setMoment(String moment) {
        this.moment = moment;
    }

    @JsonProperty("request-promise-native")
    public String getRequestPromiseNative() {
        return requestPromiseNative;
    }

    @JsonProperty("request-promise-native")
    public void setRequestPromiseNative(String requestPromiseNative) {
        this.requestPromiseNative = requestPromiseNative;
    }

    @JsonProperty("uuid")
    public String getUuid() {
        return uuid;
    }

    @JsonProperty("uuid")
    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("moment", moment).append("requestPromiseNative", requestPromiseNative).append("uuid", uuid).append("additionalProperties", additionalProperties).toString();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(requestPromiseNative).append(additionalProperties).append(moment).append(uuid).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Dependencies) == false) {
            return false;
        }
        Dependencies rhs = ((Dependencies) other);
        return new EqualsBuilder().append(requestPromiseNative, rhs.requestPromiseNative).append(additionalProperties, rhs.additionalProperties).append(moment, rhs.moment).append(uuid, rhs.uuid).isEquals();
    }

}
